//
//  NSData+AIAdditions.h
//  Adjust
//
//  Created by Christian Wellenbrock on 01.10.12.
//  Copyright (c) 2012-2013 adeven. All rights reserved.
//
#import <Foundation/Foundation.h>

@interface NSData(BetableTracking)

- (NSString *)aiEncodeBase64;

@end
