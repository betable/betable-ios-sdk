//
//  Environment.h
//  Betable
//
//  Created by Matthew Hilliard on 2016-09-14.
//  Copyright © 2016 betable. All rights reserved.
//

#ifndef Environment_h
#define Environment_h

// Running a local betable server? Uncomment this
// #define USE_LOCALHOST 1

#define BETABLE_SDK_REVISION @"v1.1.12"

#endif /* Environment_h */
