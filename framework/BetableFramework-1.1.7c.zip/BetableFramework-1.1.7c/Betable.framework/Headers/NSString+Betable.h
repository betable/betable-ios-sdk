//
//  NSString+Betable.h
//  Betable
//
//  Created by Tony hauber on 6/13/14.
//  Copyright (c) 2014 betable. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Betable)

- (NSObject*)objectFromJSONString;
- (NSString *)stringByDecodingURLFormat;
- (NSString *)stringByEncodingURLFormat;
- (NSMutableDictionary *)dictionaryFromQueryComponents;
@end
