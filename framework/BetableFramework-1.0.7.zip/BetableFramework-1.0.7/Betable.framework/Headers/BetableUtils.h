//
//  BetableUtils.h
//  Betable
//
//  Created by Tony hauber on 6/18/14.
//  Copyright (c) 2014 betable. All rights reserved.
//

#import <Foundation/Foundation.h>

id NULLIFY(NSObject *object);
id NILIFY(NSObject *object);
NSString *toString(id object);
NSString *urlEncode(id object);

@interface BetableUtils : NSObject

@end
